import webbrowser
from flask import Flask, request, jsonify, send_from_directory
import json
import os
import socket

app = Flask(__name__)

# Path to the history file
HISTORY_FILE = "history_data.json"

# Load history from file
def load_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as file:
            return json.load(file)
    return {}

# Save history to file
def save_history():
    with open(HISTORY_FILE, "w") as file:
        json.dump(history_data, file, indent=4)

# Update global history data
history_data = load_history()

@app.route('/')
def serve_history():
    return send_from_directory('.', 'website_history.html')

# Route to get history data
@app.route('/clear_history', methods=['POST'])
def clear_history_request():
    global history_data
    new_history = {}

    for site, status in history_data.items():
        if "Blocked" in status:
            new_history[site] = "Blocked"  # Retain only "Blocked" status

    history_data = new_history  # Update history with only Blocked sites
    save_history()  # Save changes to file
    return jsonify(success=True)

# Check if server is already running
def is_server_running(port=5000):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        return sock.connect_ex(("127.0.0.1", port)) == 0

# Function to start the server only when "View History" is clicked
def start_server():
    webbrowser.open("http://127.0.0.1:5000")
    if not is_server_running():
        webbrowser.open("http://127.0.0.1:5000")
        app.run(port=5000, threaded=True)
    else:
        print("Server is already running.")

# Prevent automatic execution
if __name__ == "__main__":
    print("Flask server is ready. Press 'View History' to start.")
