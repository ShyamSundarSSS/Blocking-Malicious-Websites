import sys
import os
import ctypes
import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk
import requests
import platform
import webbrowser
import threading
import json
import subprocess
from datetime import datetime
import history_server

# JSON file paths
BLOCKLIST_FILE = "blocked_websites.json"
HISTORY_FILE = "history_data.json"

# Load blocklist from JSON file
def load_blocklist():
    if not os.path.exists(BLOCKLIST_FILE):
        return []
    with open(BLOCKLIST_FILE, "r") as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return []  # Return empty list if file is corrupt

# Save blocklist to JSON file
def save_blocklist(blocked_websites):
    with open(BLOCKLIST_FILE, "w") as file:
        json.dump(blocked_websites, file, indent=4)

# Load history data from JSON file
def load_history():
    global history_data
    if not os.path.exists(HISTORY_FILE):
        history_data = {}
    else:
        with open(HISTORY_FILE, "r", encoding="utf-8") as file:
            try:
                history_data = json.load(file)
            except json.JSONDecodeError:
                history_data = {}

# Save history data to JSON file
def save_history():
    with open(HISTORY_FILE, "w", encoding="utf-8") as file:
        json.dump(history_data, file, ensure_ascii=False, indent=4)

# Function to enforce DNS settings
def enforce_dns(dns_servers=None):
    """
    Enforce secure DNS settings on the system.
    :param dns_servers: List of DNS servers (default: Cloudflare's DNS servers).
    """
    if dns_servers is None:
        dns_servers = ["1.1.1.1", "1.0.0.1"]  # Default to Cloudflare DNS

    try:
        system = platform.system()

        if system == "Windows":
            print("Applying DNS settings on Windows...")
            adapters = os.popen('wmic nicconfig where (IPEnabled=True) get Description').readlines()[1:]
            for adapter in adapters:
                adapter_name = adapter.strip()
                if adapter_name:
                    subprocess.run(["netsh", "interface", "ipv4", "set", "dns", adapter_name, "static", dns_servers[0]])
                    subprocess.run(["netsh", "interface", "ipv4", "add", "dns", adapter_name, dns_servers[1], "index=2"])
            print(f"DNS successfully set to {dns_servers[0]} and {dns_servers[1]} on Windows.")

        elif system in ["Linux", "Darwin"]:  # Linux/Mac
            print("Applying DNS settings on Linux/Mac...")
            resolv_conf_path = "/etc/resolv.conf"
            with open(resolv_conf_path, "w") as file:
                file.write(f"nameserver {dns_servers[0]}\n")
                file.write(f"nameserver {dns_servers[1]}\n")
            os.system(f"sudo chattr +i {resolv_conf_path}")
            print(f"DNS successfully set to {dns_servers[0]} and {dns_servers[1]} on Linux/Mac.")

        else:
            print(f"Unsupported operating system: {system}")

    except Exception as e:
        print(f"Failed to enforce DNS settings: {e}")

# Prevent DNS Changes (Cross-Platform)
def prevent_dns_changes():
    """
    Prevent DNS changes across Windows, Linux, and Mac systems.
    Requires administrator/root privileges.
    """
    system = platform.system()

    if system == "Windows":
        # Windows: Modify the Registry to enforce DNS settings
        print("Applying DNS restrictions on Windows...")
        try:
            if not ctypes.windll.shell32.IsUserAnAdmin():
                raise PermissionError("Administrator privileges are required to modify the registry.")

            # Registry path for DNS-related settings
            registry_path = r"SOFTWARE\Policies\Microsoft\Windows NT\DNSClient"

            # Enforce DNS over HTTPS (DoH) and disable unauthorized changes
            os.system(f'reg add "HKLM\\{registry_path}" /v "EnableDnsOverHttps" /t REG_DWORD /d 1 /f')
            os.system(f'reg add "HKLM\\{registry_path}" /v "DisableAutoDns" /t REG_DWORD /d 1 /f')

            print("DNS changes have been successfully restricted on Windows.")
        except PermissionError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Failed to prevent DNS changes on Windows: {e}")

    elif system in ["Linux", "Darwin"]:  # Linux/Mac
        # Linux/Mac: Make /etc/resolv.conf immutable
        print(f"Applying DNS restrictions on {system}...")
        try:
            resolv_conf_path = "/etc/resolv.conf"

            # Ensure the file exists
            if not os.path.exists(resolv_conf_path):
                raise FileNotFoundError(f"{resolv_conf_path} does not exist.")

            # Make /etc/resolv.conf immutable using `chattr`
            os.system(f"sudo chattr +i {resolv_conf_path}")
            print(f"DNS changes have been successfully restricted on {system}.")
        except FileNotFoundError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Failed to prevent DNS changes on {system}: {e}")

    else:
        print(f"Unsupported platform: {system}. Cannot apply DNS restrictions.")

# Initialize history data and blocked websites list
history_data = {}
blocked_websites = set(load_blocklist())

# Load the history data at the start
load_history()

# Enforce secure DNS settings at program startup
enforce_dns()

# Prevent DNS settings from being modified
prevent_dns_changes()

# Continue with the rest of your program
print("DNS enforcement and prevention complete. Proceeding with the rest of the application...")

# ------------------- STEP 0: Project Info -------------------
def open_html_page():
    # Update the path to the location of your HTML file
    html_file_path = "profile_page.html"
    webbrowser.open_new_tab(html_file_path)

# ------------------- STEP 1: Ensure Admin Privileges -------------------
def run_as_admin():
    """Restart script with admin privileges if not already running as admin."""
    if ctypes.windll.shell32.IsUserAnAdmin():
        return  # Already running as admin
    else:
        script = sys.argv[0]
        params = " ".join([f'"{arg}"' for arg in sys.argv[1:]])
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}" {params}', None, 1)
        sys.exit()

run_as_admin()  # Ensure admin rights

# ------------------- STEP 2: Setup -------------------
ADMIN_PASSWORD = "1234"
history_file = "website_history.html"
blocked_websites_file = "blocked_websites.json"
hosts_path = r"C:\Windows\System32\drivers\etc\hosts" if platform.system() == "Windows" else "/etc/hosts"

# VirusTotal API key
VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "6245ab4e916d77c0ba491527436ef655324171bc6c3cfc1364186bd4373f9eb5")

def check_website_virustotal(website):
    """Check website safety using VirusTotal API."""
    urls = [
        f"https://www.virustotal.com/api/v3/domains/{website}",
        f"https://www.virustotal.com/api/v3/domains/www.{website}"
    ]
    headers = {"x-apikey": VIRUSTOTAL_API_KEY}

    for url in urls:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            malicious_score = data["data"]["attributes"]["last_analysis_stats"]["malicious"]
            return malicious_score
    return None

# Google Safety API key
GOOGLE_SAFETY_API_KEY = os.getenv("GOOGLE_SAFETY_API_KEY", "AIzaSyBDYjqZGARQnKTBOC9BaCPg6U-0fgVAKM0")

def check_website_google_safety(website):
    """Check website safety using Google Safety API."""
    params = {
        "key": GOOGLE_SAFETY_API_KEY,
        "client": "your_client_id",
        "appver": "1.0",
        "pver": "3.0",
        "url": f"http://{website}"
    }
    response = requests.get("https://safebrowsing.googleapis.com/v4/threatMatches:find", params=params)
    if response.status_code == 200:
        data = response.json()
        if "matches" in data:
            return True
    return False

# ------------------- STEP 3: Load & Resize Background Image -------------------
IMAGE_PATH = "internet_censorship.png"

if not os.path.exists(IMAGE_PATH):
    messagebox.showerror("Error", f"Image file '{IMAGE_PATH}' not found!")
    sys.exit()

# Load the initial image to get its size
bg_image = Image.open(IMAGE_PATH)
image_width, image_height = bg_image.size

# ------------------- STEP 4: Create GUI -------------------
root = tk.Tk()
root.title("Website Security Check")
root.geometry(f"{image_width}x{image_height}")

# Background Image Handling
def update_background(image_path):
    """Resize and update background image dynamically."""
    global bg_image, bg_photo, image_width, image_height
    bg_image = Image.open(image_path)
    image_width, image_height = bg_image.size
    root.geometry(f"{image_width}x{image_height}")
    bg_image = bg_image.resize((image_width, image_height), Image.Resampling.LANCZOS)
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label.config(image=bg_photo)

bg_image = Image.open(IMAGE_PATH)
bg_photo = ImageTk.PhotoImage(bg_image)
bg_label = tk.Label(root, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Style Configuration
style = ttk.Style()
style.configure("TButton", font=("Arial", 10), padding=5)
style.configure("TLabel", font=("Arial", 12), background="white")

# ------------------- STEP 5: UI Elements -------------------
frame = tk.Frame(root, bg="white", padx=20, pady=20)
frame.pack(pady=20)

url_frame = tk.LabelFrame(frame, text="Enter Website", fg="black", font=("Arial", 14, "bold"), padx=5, pady=5, bd=2, labelanchor="n")
url_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
url_frame.grid_columnconfigure(1, weight=1)

website_entry = ttk.Entry(url_frame, width=40)
website_entry.grid(row=0, column=1, padx=5, pady=5)

def on_check_button_click(event):
    """Handle the check button click event."""
    check_website()

check_button = ttk.Button(url_frame, text="Check Website")
check_button.grid(row=1, column=1, padx=5, pady=5, sticky="e")
check_button.bind("<Button-1>", on_check_button_click)

result_label = ttk.Label(frame, text="")
result_label.grid(row=1, columnspan=2, padx=5, pady=5)

# Load blocked websites from file
def load_blocked_websites():
    """Load blocked websites from file."""
    global blocked_websites
    if os.path.exists(blocked_websites_file):
        with open(blocked_websites_file, "r") as file:
            blocked_websites = set(json.load(file))
        # Load blocked websites into the hosts file
        with open(hosts_path, "r") as file:
            hosts_lines = file.readlines()
        with open(hosts_path, "w") as file:
            for line in hosts_lines:
                if not any(website in line for website in blocked_websites):
                    file.write(line)
            for website in blocked_websites:
                file.write(f"127.0.0.1 {website}\n127.0.0.1 www.{website}\n")

# Save blocked websites to file
def save_blocked_websites():
    """Save blocked websites to file."""
    with open(blocked_websites_file, "w") as file:
        json.dump(list(blocked_websites), file)

load_blocked_websites()

def save_history():
    """Save history data to a JSON file."""
    with open("history_data.json", "w", encoding="utf-8") as file:
        json.dump(history_data, file, ensure_ascii=False, indent=4)

# ------------------- STEP 6: Website Safety Check & History -------------------
def update_history():
    """
    Update the history file with tables for Safe, Malicious, and Blocked websites.
    No third column is included; only "Sites" and "Reported Time" are displayed.
    """
    with open("website_history.html", "w", encoding="utf-8") as file:
        # Start of the HTML structure
        file.write("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 20px;
            color: #333;
        }
        h2 {
            color: #0056b3;
            font-size: 1.8em;
        }
        h3 {
            font-size: 1.5em;
            margin-top: 20px;
            display: flex;
            align-items: center;
        }
        h3::before {
            content: attr(data-emoji);
            margin-right: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .clear-history-button {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            padding: 10px 20px;
            font-size: 1em;
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .clear-history-button:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        function clearHistory() {
            fetch('/clear_history', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    console.error('Failed to clear history:', data.message);
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        }
    </script>
</head>
<body>
    <button class="clear-history-button" onclick="clearHistory()">Clear History</button>
    <h2>Website History</h2>
        """)

        # Helper function to create tables for Safe, Malicious, and Blocked websites
        def write_table(category, data, emoji):
            file.write(f"<h3 data-emoji='{emoji}'>{category} Websites</h3>\n")
            file.write("<table>\n<tr><th>Sites</th><th>Reported Time</th></tr>\n")
            for site, details in data.items():
                if category in details["status"]:  # Matches status like "Safe" or "Safe and Blocked"
                    file.write(f"<tr><td>{site}</td><td>{details['timestamp']}</td></tr>\n")
            file.write("</table>\n")

        # Generate tables for each category
        write_table("Safe", history_data, "✅")       # Green tick for Safe
        write_table("Malicious", history_data, "⚠️") # Warning sign for Malicious
        write_table("Blocked", history_data, "🚫")   # Stop sign for Blocked

        file.write("""
</body>
</html>
        """)

# Flask server to handle delete requests and clear history requests
from flask import Flask, jsonify, send_from_directory

app = Flask(__name__)

@app.route('/')
def serve_history():
    return send_from_directory('.', 'website_history.html')

#------------------- Clear History -------------------
@app.route('/clear_history', methods=['POST'])
def clear_history_request():
    """
    Clear Safe and Malicious entries from history while preserving Blocked entries.
    If an entry has combined statuses like "Safe and Blocked" or "Malicious and Blocked,"
    it will retain only the "Blocked" part of the status.
    """
    global history_data
    new_history = {}

    for site, details in history_data.items():
        # Check if the site has "Blocked" in its status
        if "Blocked" in details["status"]:
            # Retain only the "Blocked" part of the status
            details["status"] = "Blocked"
            new_history[site] = details
        # If the site does not have "Blocked" in its status, it is removed
        elif "Safe" not in details["status"] and "Malicious" not in details["status"]:
            new_history[site] = details  # Unrelated entries stay untouched

    history_data = new_history  # Update history to include only Blocked entries or unrelated entries
    save_history()  # Save changes to the file
    update_history()  # Update the HTML history
    return jsonify(success=True)

#------------------- Run Separate Thread -------------------
if __name__ == '__main__':
    threading.Thread(target=app.run).start()  # Run Flask server in a separate thread

# ------------------- STEP 6: Website Safety Check & History -------------------
def check_website():
    """
    Check website safety using VirusTotal and Google Safety APIs.
    Mark entries with timestamps.
    """
    website = website_entry.get().strip().replace("https://", "").replace("http://", "").split('/')[0]
    if not website:
        messagebox.showerror("Error", "Enter a website.")
        return

    malicious_score = check_website_virustotal(website)
    is_unsafe = check_website_google_safety(website)

    virus_total_safe = malicious_score is None or malicious_score == 0
    google_safe = not is_unsafe

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if virus_total_safe and google_safe:
        history_data[website] = {"status": "Safe", "timestamp": timestamp}
        messagebox.showinfo("Result", f"Website '{website}' is Safe.\nReported Time: {timestamp}")
    else:
        block_response = messagebox.askyesno("Malicious Detected", f"Malicious detected.\nReported Time: {timestamp}\nDo you want to block this website?")
        history_data[website] = {"status": "Malicious", "timestamp": timestamp}
        if block_response:
            block_website()

    save_history()
    update_history()

# ------------------- Password Prompt -------------------
def prompt_password(callback, block_or_unblock):
    """
    Prompt the user for the admin password and execute the callback if correct.
    The layout ensures three distinct lines: Label, Password Entry, and Buttons.
    """
    password_window = tk.Toplevel(root)
    password_window.title("Enter Password")
    password_window.geometry("400x150")  # Adjust height for the new layout

    # Frame for the label and password entry
    frame = tk.Frame(password_window)
    frame.pack(pady=10)

    # First line: Label for the password entry
    tk.Label(frame, text="Enter Password:").grid(row=0, column=0, padx=(5, 10), pady=5)

    # Second line: Password entry and toggle button
    password_frame = tk.Frame(frame)
    password_frame.grid(row=0, column=1, padx=(0, 10), pady=5, sticky="ew")

    password_entry = ttk.Entry(password_frame, show="*", width=25)
    password_entry.grid(row=0, column=0, sticky="ew")

    # Eye button to toggle password visibility
    eye_button = tk.Button(password_frame, text="🔒", command=lambda: toggle_password(password_entry, eye_button), width=2, relief="raised", borderwidth=2)
    eye_button.grid(row=0, column=1, padx=(2, 0), pady=0, sticky="e")

    def toggle_password(entry, button):
        """Toggle visibility of password entry."""
        if entry.cget("show") == "*":
            entry.config(show="")
            button.config(text="👁")  # Open eye emoji
        else:
            entry.config(show="*")
            button.config(text="🔒")  # Lock emoji

    def validate_password():
        """Validate password and execute the callback function if correct."""
        password = password_entry.get().strip()
        if password == ADMIN_PASSWORD:
            password_window.destroy()
            callback()  # Execute the action after successful validation
        else:
            messagebox.showerror("Error", "Invalid password.")

    def cancel_action():
        """Close the password window without performing any action."""
        password_window.destroy()

    # Third line: Frame for buttons (Block/Unblock and Cancel)
    button_frame = tk.Frame(password_window)
    button_frame.pack(pady=20)  # Add vertical spacing between password entry and buttons

    # Cancel button
    cancel_button = ttk.Button(button_frame, text="Cancel", command=cancel_action)
    cancel_button.pack(side=tk.LEFT, padx=10)

    # Block/Unblock button
    action_button = ttk.Button(button_frame, text=block_or_unblock, command=validate_password)
    action_button.pack(side=tk.LEFT, padx=10)

# ------------------- Clear DNS Cache -------------------
def clear_dns_cache():
    """Clear the DNS cache and browser cache (if needed) based on the operating system."""
    try:
        os_name = platform.system()

        # OS-level DNS cache clearing
        if os_name == "Windows":
            subprocess.run(["ipconfig", "/flushdns"], check=True)
        elif os_name == "Darwin":  # macOS
            subprocess.run(["sudo", "killall", "-HUP", "mDNSResponder"], check=True)
        elif os_name == "Linux":
            subprocess.run(["sudo", "systemctl", "restart", "NetworkManager"], check=True)

        # Force browser DNS cache clearing
        clear_browser_cache()

    except Exception as e:
        print(f"Failed to clear DNS cache: {str(e)}")

def clear_browser_cache():
    """Force browsers to clear their DNS cache by closing them."""
    try:
        browsers = ["chrome", "firefox", "msedge", "safari", "brave"]
        
        if platform.system() == "Windows":
            for browser in browsers:
                subprocess.run(["taskkill", "/IM", f"{browser}.exe", "/F"], stderr=subprocess.DEVNULL)
        else:  # macOS & Linux
            for browser in browsers:
                subprocess.run(["pkill", "-f", browser], stderr=subprocess.DEVNULL)

    except Exception as e:
        print(f"Failed to clear browser cache: {str(e)}")

# ------------------- Block Website -------------------
def block_website():
    """
    Block a website and its subdomains in the system's hosts file.
    Add the Blocked status and timestamp while preserving Safe/Malicious status.
    """
    website = website_entry.get().strip().replace("https://", "").replace("http://", "").split('/')[0]
    if not website:
        messagebox.showerror("Error", "Enter a website.")
        return

    if website in blocked_websites:
        messagebox.showwarning("Warning", f"Website '{website}' is already blocked.")
        return

    def block_action():
        try:
            with open(hosts_path, "a") as hosts_file:
                hosts_file.write(f"127.0.0.1 {website}\n")
                if not website.startswith("www."):
                    hosts_file.write(f"127.0.0.1 www.{website}\n")
                # Block all subdomains
                hosts_file.write(f"127.0.0.1 .{website}\n")
            
            blocked_websites.add(website)
            save_blocklist(list(blocked_websites))  # Save blocklist to JSON file

            # Update history_data
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if website in history_data:
                # Append "Blocked" to the existing status
                history_data[website]["status"] = f"{history_data[website]['status']} and Blocked"
                history_data[website]["blocked_time"] = timestamp
            else:
                # Add new entry for Blocked website
                history_data[website] = {
                    "status": "Blocked",
                    "timestamp": timestamp,
                    "blocked_time": timestamp
                }

            save_history()  # Save updated history
            update_history()  # Update the HTML history
            clear_dns_cache()  # Clear DNS cache for changes to take effect
            messagebox.showinfo("Success", f"Website '{website}' has been blocked successfully.")
        except PermissionError:
            messagebox.showerror("Error", "Run as Administrator.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to block website: {str(e)}")

    prompt_password(block_action, "Block")

# ------------------- Unblock Website -------------------
def unblock_website():
    """
    Unblock a website and its subdomains in the system's hosts file.
    Remove the Blocked status and update the history_data accordingly.
    """
    website = website_entry.get().strip().replace("https://", "").replace("http://", "").split('/')[0]
    if not website:
        messagebox.showerror("Error", "Enter a website.")
        return

    if website not in blocked_websites:
        messagebox.showwarning("Warning", f"Website '{website}' is not blocked.")
        return

    def unblock_action():
        try:
            # Remove website from system hosts file
            with open(hosts_path, "r") as file:
                lines = file.readlines()
            with open(hosts_path, "w") as file:
                for line in lines:
                    if website not in line and f"www.{website}" not in line and f".{website}" not in line:
                        file.write(line)

            blocked_websites.remove(website)
            save_blocklist(list(blocked_websites))  # Save updated blocklist

            # Update history_data
            if website in history_data:
                if "Blocked" in history_data[website]["status"]:
                    # Remove "Blocked" from the status
                    if "Safe and Blocked" in history_data[website]["status"]:
                        history_data[website]["status"] = "Safe"
                    elif "Malicious and Blocked" in history_data[website]["status"]:
                        history_data[website]["status"] = "Malicious"
                    else:
                        del history_data[website]  # If only "Blocked," remove the entry

            save_history()  # Save updated history
            update_history()  # Update the HTML history
            clear_dns_cache()  # Clear DNS cache for changes to take effect
            messagebox.showinfo("Success", f"Website '{website}' has been unblocked successfully.")
        except PermissionError:
            messagebox.showerror("Error", "Run as Administrator.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to unblock website: {str(e)}")

    prompt_password(unblock_action, "Unblock")

# ------------------- Info Button Style -------------------
# Style Configuration
style = ttk.Style()
style.configure("TButton", font=("Arial", 10), padding=5)
style.configure("TLabel", font=("Arial", 12), background="white")

# Add this for colorful button with black text
style.configure("Colorful.TButton", font=("Arial", 10, "bold"), padding=5, foreground="black", background="#4CAF50")
style.map("Colorful.TButton", background=[("active", "#45a049")])

# ------------------- Open History -------------------
def open_history():
    """Open the history file in a web browser."""
    webbrowser.open(history_file)

# Function to open the HTML page
def open_html_page():
    # Update the path to the location of your HTML file
    html_file_path = r"profile_page.html"
    webbrowser.open_new_tab(html_file_path)

# ------------------- STEP 7: UI Buttons -------------------

open_html_button = ttk.Button(root, text="Open Project Info", command=open_html_page, style="Colorful.TButton")
open_html_button.place(relx=1.0, rely=0.0, anchor="ne", x=-10, y=10)

button_frame = tk.LabelFrame(root, text="Options", fg="black", font=("Arial", 14, "bold"), bg="white", padx=10, pady=10, bd=2, labelanchor="n")
button_frame.pack(pady=10)

block_button = ttk.Button(button_frame, text="Block Website", command=block_website)
block_button.grid(row=1, column=0, padx=10, pady=5)

unblock_button = ttk.Button(button_frame, text="Unblock Website", command=unblock_website)
unblock_button.grid(row=1, column=1, padx=10, pady=5)

def View_History():
    return history_server.start_server()

history_button = ttk.Button(button_frame, text="View History", command=View_History)
history_button.grid(row=1, column=2, padx=10, pady=5)

# Start the Tkinter event loop
root.mainloop()
